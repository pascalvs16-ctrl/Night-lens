# Night Lens - offline ortho-k lens & solution tracker

Android app that tracks night lens replacement, lens fluid, cleaning solutions A and B,
and optometrist appointments. Fully offline: no internet permission, no account, all data
stored locally on the phone.

## Schedule built in (anchor: 21 August 2026, 21:00)

| Item | Interval | Warnings before due |
|---|---|---|
| Replace night lenses | 365 days | 1 month (= book appointment), 1 week, 1 day, on the day |
| New lens fluid | 45 days (1.5 months) | 1 week, 1 day, on the day |
| Cleaning solution A | 30 days | 1 week, 1 day, on the day |
| Cleaning solution B | 30 days | 1 week, 1 day, on the day |

Reminders fire at 20:00 by default; change it with "Change reminder time".
Every item has "Done today" (resets the interval from today) and "Set date..." (correct the
last-done date). Alarms are re-scheduled after a reboot.

## Appointments
"+ Add appointment" offers preset types (yearly check-up, new fitting, follow-up, complaint
visit, custom), then a date and time picker. Each appointment notifies 1 week before,
1 day before and 2 hours before. "Add to calendar" pushes it to the phone calendar app.

## How to get the .apk

### Option A - GitHub (no software to install)
1. Create a new repository on github.com and upload this whole folder.
2. Go to the "Actions" tab -> "Build APK" -> "Run workflow".
3. When it finishes, download the artifact "night-lens-apk". Inside is `app-debug.apk`.
4. Copy it to your phone, tap it, allow "install unknown apps".

### Option B - Android Studio
1. Install Android Studio (free), File > Open, select this folder.
2. Let it sync (it downloads Gradle and the SDK automatically).
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
4. The APK lands in `app/build/outputs/apk/debug/`.

## After installing
- Allow notifications when asked.
- If a yellow banner appears, tap it and allow "Alarms & reminders" (exact alarms), otherwise
  Android may delay reminders by a few hours.
- On Samsung/Xiaomi/OnePlus: set the app to "unrestricted" battery usage, or aggressive
  battery savers will kill scheduled alarms.

## Changing intervals
Intervals live in `Store.kt` -> `defaults()`. Change the number of days there and rebuild.
The anchor date is in `Store.kt` -> `anchor()`.
