package nl.pascal.nightlens

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "nightlens_reminders"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        CHANNEL_ID,
                        "Lens reminders",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    ch.description = "Night lens cleaning, replacement and appointment reminders"
                    ch.enableVibration(true)
                    nm.createNotificationChannel(ch)
                }
            }
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        ensureChannel(ctx)

        val title = intent.getStringExtra(Scheduler.EXTRA_TITLE) ?: "Night lens reminder"
        val text = intent.getStringExtra(Scheduler.EXTRA_TEXT) ?: ""
        val id = intent.getIntExtra(Scheduler.EXTRA_NOTIF_ID, 1)

        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()

        try {
            androidx.core.app.NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
            // notification permission not granted
        }

        // Keep the chain alive for future dates.
        Scheduler.scheduleAll(ctx)
    }
}
