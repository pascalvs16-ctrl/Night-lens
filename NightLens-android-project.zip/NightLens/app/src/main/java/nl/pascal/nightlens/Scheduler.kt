package nl.pascal.nightlens

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Scheduler {
    const val EXTRA_TITLE = "x_title"
    const val EXTRA_TEXT = "x_text"
    const val EXTRA_NOTIF_ID = "x_id"

    private const val CODE_START = 2000
    private const val CODE_END = 2400

    fun atHour(timeMs: Long, hour: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = timeMs
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun nextHourSlot(hour: Int): Long {
        val now = System.currentTimeMillis()
        var t = atHour(now, hour)
        if (t <= now) t += DAY_MS
        return t
    }

    private fun leadText(lead: Int, t: Task): String = when (lead) {
        30 -> "Due in one month. Time to book your optometrist appointment."
        7 -> "Due in one week. " + t.detail
        1 -> "Due tomorrow. " + t.detail
        else -> "Due today. " + t.detail
    }

    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        cancelRange(ctx, am)

        val hour = Store.reminderHour(ctx)
        val now = System.currentTimeMillis()
        var code = CODE_START

        for (t in Store.tasks(ctx)) {
            for (lead in t.leadDays) {
                code++
                val fire = atHour(t.nextDue - lead * DAY_MS, hour)
                if (fire > now) set(ctx, am, code, fire, t.name, leadText(lead, t))
            }
            if (t.nextDue < now) {
                code++
                set(ctx, am, code, nextHourSlot(hour), t.name, "OVERDUE - " + t.detail)
            }
        }

        for (a in Store.appointments(ctx)) {
            for (lead in listOf(7, 1)) {
                code++
                val fire = atHour(a.timeMs - lead * DAY_MS, hour)
                if (fire > now) {
                    val word = if (lead == 7) "in one week" else "tomorrow"
                    set(ctx, am, code, fire, "Appointment " + word, a.title)
                }
            }
            code++
            val soon = a.timeMs - 2 * 3600_000L
            if (soon > now) set(ctx, am, code, soon, "Appointment in 2 hours", a.title)
        }
    }

    private fun cancelRange(ctx: Context, am: AlarmManager) {
        for (c in CODE_START..CODE_END) {
            val i = Intent(ctx, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                ctx, c, i,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    private fun set(
        ctx: Context, am: AlarmManager, code: Int,
        whenMs: Long, title: String, text: String
    ) {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_TEXT, text)
            putExtra(EXTRA_NOTIF_ID, code)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, code, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        }
    }
}
