package nl.pascal.nightlens

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private val df = SimpleDateFormat("EEE d MMM yyyy", Locale.getDefault())
    private val dfTime = SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.getDefault())

    private val bg = Color.parseColor("#0E1420")
    private val card = Color.parseColor("#1B2436")
    private val accent = Color.parseColor("#4FC3F7")
    private val warn = Color.parseColor("#FFB74D")
    private val bad = Color.parseColor("#EF5350")
    private val fg = Color.parseColor("#ECEFF4")
    private val dim = Color.parseColor("#9AA7BD")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(dp(16), dp(20), dp(16), dp(32))
        scroll.addView(container)
        setContentView(scroll)

        AlarmReceiver.ensureChannel(this)
        askNotificationPermission()
        Scheduler.scheduleAll(this)
        render()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        render()
    }

    // ---------- UI ----------

    private fun render() {
        container.removeAllViews()

        container.addView(title("Night Lens Tracker"))
        container.addView(sub("Reminders at " + String.format(Locale.getDefault(), "%02d:00", Store.reminderHour(this)) + " - offline, no account needed"))

        val hourBtn = flatButton("Change reminder time") {
            val cur = Store.reminderHour(this)
            TimePickerDialog(this, { _, h, _ ->
                Store.setReminderHour(this, h)
                Scheduler.scheduleAll(this)
                render()
            }, cur, 0, true).show()
        }
        container.addView(hourBtn)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                container.addView(warnBanner("Exact alarms are off - reminders may be delayed. Tap to allow.") {
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                    } catch (e: Exception) {
                        toast("Open Settings > Apps > Night Lens > Alarms & reminders")
                    }
                })
            }
        }

        container.addView(section("Lens & solution schedule"))
        val tasks = Store.tasks(this)
        for (t in tasks) container.addView(taskCard(t, tasks))

        container.addView(section("Appointments"))
        val appts = Store.appointments(this)
        if (appts.isEmpty()) container.addView(sub("No appointments planned yet."))
        for (a in appts) container.addView(apptCard(a))

        container.addView(primaryButton("+ Add appointment") { addAppointmentFlow() })
    }

    private fun taskCard(t: Task, all: MutableList<Task>): LinearLayout {
        val box = cardBox()
        val days = daysUntil(t.nextDue)
        val statusColor = when {
            days < 0 -> bad
            days <= 7 -> warn
            else -> accent
        }
        val statusText = when {
            days < 0 -> "OVERDUE by " + (-days) + " day(s)"
            days == 0L -> "DUE TODAY"
            days == 1L -> "Due tomorrow"
            else -> "Due in " + days + " days"
        }

        box.addView(text(t.name, 18f, fg, true))
        box.addView(text(t.detail + "  -  every " + t.intervalDays + " days", 13f, dim, false))
        box.addView(text(statusText, 16f, statusColor, true))
        box.addView(text("Next: " + df.format(Date(t.nextDue)) + "\nLast done: " + df.format(Date(t.lastDone)), 13f, dim, false))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallButton("Done today") {
            t.lastDone = System.currentTimeMillis()
            Store.saveTasks(this, all)
            Scheduler.scheduleAll(this)
            toast(t.name + " reset. Next: " + df.format(Date(t.nextDue)))
            render()
        })
        row.addView(smallButton("Set date...") {
            val c = Calendar.getInstance()
            c.timeInMillis = t.lastDone
            DatePickerDialog(this, { _, y, m, d ->
                val n = Calendar.getInstance()
                n.set(y, m, d, 21, 0, 0)
                n.set(Calendar.MILLISECOND, 0)
                t.lastDone = n.timeInMillis
                Store.saveTasks(this, all)
                Scheduler.scheduleAll(this)
                render()
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        })
        box.addView(row)

        val leads = t.leadDays.filter { it > 0 }.joinToString(", ") { it.toString() + "d" }
        box.addView(text("Warnings: " + leads + " before + on the day", 12f, dim, false))
        return box
    }

    private fun apptCard(a: Appointment): LinearLayout {
        val box = cardBox()
        val days = daysUntil(a.timeMs)
        box.addView(text(a.title, 17f, fg, true))
        box.addView(text(dfTime.format(Date(a.timeMs)), 14f, if (days < 0) dim else accent, false))
        if (a.note.isNotBlank()) box.addView(text(a.note, 13f, dim, false))
        box.addView(
            text(
                if (days < 0) "Passed" else if (days == 0L) "Today" else "In " + days + " day(s)",
                13f, if (days in 0..7) warn else dim, false
            )
        )

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallButton("Add to calendar") {
            try {
                val i = Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, a.timeMs)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, a.timeMs + 3600_000L)
                    .putExtra(CalendarContract.Events.TITLE, a.title)
                    .putExtra(CalendarContract.Events.DESCRIPTION, a.note)
                startActivity(i)
            } catch (e: Exception) {
                toast("No calendar app found")
            }
        })
        row.addView(smallButton("Delete") {
            val list = Store.appointments(this)
            list.removeAll { it.id == a.id }
            Store.saveAppointments(this, list)
            Scheduler.scheduleAll(this)
            render()
        })
        box.addView(row)
        return box
    }

    // ---------- appointment creation ----------

    private fun addAppointmentFlow() {
        val options = arrayOf(
            "Yearly lens check-up (optometrist)",
            "New lens fitting / replacement",
            "Follow-up / control visit",
            "Problem or complaint visit",
            "Custom..."
        )
        AlertDialog.Builder(this)
            .setTitle("Appointment type")
            .setItems(options) { _, which ->
                if (which == options.size - 1) askCustomTitle() else pickDate(options[which])
            }
            .show()
    }

    private fun askCustomTitle() {
        val input = EditText(this)
        input.hint = "Appointment title"
        AlertDialog.Builder(this)
            .setTitle("Custom appointment")
            .setView(input)
            .setPositiveButton("Next") { _, _ ->
                val t = input.text.toString().ifBlank { "Appointment" }
                pickDate(t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickDate(titleText: String) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val n = Calendar.getInstance()
                n.set(y, m, d, h, min, 0)
                n.set(Calendar.MILLISECOND, 0)
                val list = Store.appointments(this)
                list.add(Appointment(Store.nextAppointmentId(this), titleText, n.timeInMillis, ""))
                Store.saveAppointments(this, list)
                Scheduler.scheduleAll(this)
                toast("Saved. You get a warning 1 week, 1 day and 2 hours before.")
                render()
            }, 10, 0, true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---------- helpers ----------

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun daysUntil(ms: Long): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val today = c.timeInMillis
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return (c.timeInMillis - today) / DAY_MS
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(topMargin: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(topMargin)
        return p
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = s
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        tv.layoutParams = lp(4)
        return tv
    }

    private fun title(s: String): TextView {
        val tv = text(s, 24f, fg, true)
        tv.layoutParams = lp(0)
        return tv
    }

    private fun sub(s: String) = text(s, 13f, dim, false)

    private fun section(s: String): TextView {
        val tv = text(s.uppercase(Locale.getDefault()), 13f, accent, true)
        tv.layoutParams = lp(22)
        return tv
    }

    private fun cardBox(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(card)
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        box.layoutParams = lp(10)
        return box
    }

    private fun smallButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 12f
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.setBackgroundColor(accent)
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.topMargin = dp(8)
        p.marginEnd = dp(6)
        b.layoutParams = p
        b.setOnClickListener { action() }
        return b
    }

    private fun primaryButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.setBackgroundColor(accent)
        b.layoutParams = lp(16)
        b.setOnClickListener { action() }
        return b
    }

    private fun flatButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 12f
        b.isAllCaps = false
        b.setTextColor(fg)
        b.setBackgroundColor(card)
        b.gravity = Gravity.CENTER
        b.layoutParams = lp(10)
        b.setOnClickListener { action() }
        return b
    }

    private fun warnBanner(msg: String, action: () -> Unit): TextView {
        val tv = text(msg, 13f, Color.BLACK, true)
        tv.setBackgroundColor(warn)
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.layoutParams = lp(12)
        tv.setOnClickListener { action() }
        return tv
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
