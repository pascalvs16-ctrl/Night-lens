package nl.pascal.nightlens

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

const val DAY_MS = 86_400_000L

data class Task(
    val id: Int,
    val name: String,
    val detail: String,
    val intervalDays: Int,
    var lastDone: Long,
    val leadDays: List<Int>
) {
    val nextDue: Long get() = lastDone + intervalDays * DAY_MS
}

data class Appointment(
    val id: Int,
    val title: String,
    val timeMs: Long,
    val note: String
)

object Store {
    private const val PREFS = "nightlens_prefs"
    private const val KEY_TASKS = "tasks"
    private const val KEY_APPTS = "appts"
    private const val KEY_HOUR = "reminder_hour"
    private const val KEY_SEEDED = "seeded"

    /** "Yesterday night" starting point: 21 Aug 2026, 21:00 local time. */
    fun anchor(): Long {
        val c = Calendar.getInstance()
        c.set(2026, Calendar.AUGUST, 21, 21, 0, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun reminderHour(ctx: Context): Int = prefs(ctx).getInt(KEY_HOUR, 20)

    fun setReminderHour(ctx: Context, h: Int) {
        prefs(ctx).edit().putInt(KEY_HOUR, h).apply()
    }

    private fun defaults(): MutableList<Task> {
        val a = anchor()
        return mutableListOf(
            Task(1, "Replace night lenses", "Yearly lens replacement", 365, a, listOf(30, 7, 1, 0)),
            Task(2, "New lens fluid", "Fresh storage/saline fluid every 6 weeks", 45, a, listOf(7, 1, 0)),
            Task(3, "Cleaning solution A", "Replace bottle A monthly", 30, a, listOf(7, 1, 0)),
            Task(4, "Cleaning solution B", "Replace bottle B monthly", 30, a, listOf(7, 1, 0))
        )
    }

    fun tasks(ctx: Context): MutableList<Task> {
        val p = prefs(ctx)
        if (!p.getBoolean(KEY_SEEDED, false)) {
            val d = defaults()
            saveTasks(ctx, d)
            p.edit().putBoolean(KEY_SEEDED, true).apply()
            return d
        }
        val raw = p.getString(KEY_TASKS, null) ?: return defaults()
        val out = mutableListOf<Task>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val leads = mutableListOf<Int>()
                val la = o.getJSONArray("leads")
                for (j in 0 until la.length()) leads.add(la.getInt(j))
                out.add(
                    Task(
                        o.getInt("id"), o.getString("name"), o.getString("detail"),
                        o.getInt("interval"), o.getLong("lastDone"), leads
                    )
                )
            }
        } catch (e: Exception) {
            return defaults()
        }
        return if (out.isEmpty()) defaults() else out
    }

    fun saveTasks(ctx: Context, list: List<Task>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id); o.put("name", t.name); o.put("detail", t.detail)
            o.put("interval", t.intervalDays); o.put("lastDone", t.lastDone)
            val la = JSONArray()
            for (l in t.leadDays) la.put(l)
            o.put("leads", la)
            arr.put(o)
        }
        prefs(ctx).edit().putString(KEY_TASKS, arr.toString()).apply()
    }

    fun appointments(ctx: Context): MutableList<Appointment> {
        val raw = prefs(ctx).getString(KEY_APPTS, null) ?: return mutableListOf()
        val out = mutableListOf<Appointment>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Appointment(
                        o.getInt("id"), o.getString("title"),
                        o.getLong("time"), o.optString("note", "")
                    )
                )
            }
        } catch (e: Exception) {
            return mutableListOf()
        }
        out.sortBy { it.timeMs }
        return out
    }

    fun saveAppointments(ctx: Context, list: List<Appointment>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id); o.put("title", a.title)
            o.put("time", a.timeMs); o.put("note", a.note)
            arr.put(o)
        }
        prefs(ctx).edit().putString(KEY_APPTS, arr.toString()).apply()
    }

    fun nextAppointmentId(ctx: Context): Int {
        val l = appointments(ctx)
        return (l.maxOfOrNull { it.id } ?: 0) + 1
    }
}
